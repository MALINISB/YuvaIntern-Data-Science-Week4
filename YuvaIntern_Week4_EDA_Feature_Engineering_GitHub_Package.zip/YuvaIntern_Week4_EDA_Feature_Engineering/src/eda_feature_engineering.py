"""
Week 4: Exploratory Data Analysis and Feature Engineering
Project: Beauty & Wellness AI Personalization and Retention System

This script uses a clearly labelled synthetic teaching dataset. Replace the CSV
with your approved preprocessed dataset to analyze real observations.
Run: python src/eda_feature_engineering.py
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "beauty_wellness_customers.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def load_data(path=DATA):
    df = pd.read_csv(path)
    required = {"customer_id", "age", "skin_type", "product_category",
                "average_order_value", "product_rating", "purchase_count",
                "days_since_last_purchase", "discount_percent", "review_count",
                "loyalty_tier", "estimated_total_spend"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    return df

def create_features(df):
    """Create interpretable business features; avoid using target-derived leakage."""
    x = df.copy()
    x["age_group"] = pd.cut(
        x["age"], bins=[17, 24, 34, 44, 54, 100],
        labels=["18-24", "25-34", "35-44", "45-54", "55+"]
    )
    x["recency_segment"] = pd.cut(
        x["days_since_last_purchase"], bins=[0, 30, 90, 180, np.inf],
        labels=["Recent (0-30d)", "At risk (31-90d)",
                "Lapsed (91-180d)", "Dormant (180d+)"]
    )
    x["purchase_frequency_proxy"] = x["purchase_count"] / (
        x["days_since_last_purchase"].clip(lower=1) / 30
    )
    x["discount_spend_interaction"] = x["discount_percent"] * x["average_order_value"]
    x["rating_review_interaction"] = x["product_rating"] * np.log1p(x["review_count"])
    x["high_value_customer"] = (
        x["estimated_total_spend"] >= x["estimated_total_spend"].median()
    ).astype(int)
    x["rating_band"] = pd.cut(
        x["product_rating"], bins=[0, 2.5, 3.5, 4.25, 5.01],
        labels=["Low", "Medium", "Good", "Excellent"]
    )
    return x

def run_eda(df):
    report = []
    report.append(f"Rows: {len(df)} | Columns: {len(df.columns)}")
    report.append("\\nMissing values by column:\\n" + df.isna().sum().to_string())
    report.append("\\nNumeric summary:\\n" + df.select_dtypes(include=np.number).describe().round(2).to_string())
    report.append("\\nCategory counts (product_category):\\n" + df["product_category"].value_counts().to_string())

    # Missingness visualization
    plt.figure(figsize=(10, 4))
    df.isna().mean().sort_values(ascending=False).plot(kind="bar")
    plt.title("Missing-value proportion by column")
    plt.ylabel("Proportion missing")
    plt.tight_layout()
    plt.savefig(OUT / "missing_values.png", dpi=160)
    plt.close()

    # Distribution
    plt.figure(figsize=(8, 5))
    plt.hist(df["average_order_value"].dropna(), bins=25, edgecolor="black")
    plt.title("Average order value distribution")
    plt.tight_layout()
    plt.savefig(OUT / "average_order_value_distribution.png", dpi=160)
    plt.close()

    # Category comparison
    plt.figure(figsize=(9, 5))
    df.boxplot(column="average_order_value", by="product_category", grid=False)
    plt.title("Average order value by product category")
    plt.xticks(rotation=20)
    plt.tight_layout()
    plt.savefig(OUT / "order_value_by_category.png", dpi=160)
    plt.close()

    # Correlation heatmap
    num = df.select_dtypes(include=np.number)
    plt.figure(figsize=(10, 7))
    corr = num.corr(numeric_only=True)
    im = plt.imshow(corr, aspect="auto")
    plt.colorbar(im)
    plt.xticks(range(len(corr.columns)), corr.columns, rotation=75, ha="right")
    plt.yticks(range(len(corr.columns)), corr.columns)
    for i in range(len(corr.columns)):
        for j in range(len(corr.columns)):
            plt.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center", fontsize=7)
    plt.title("Correlation matrix for numeric variables")
    plt.tight_layout()
    plt.savefig(OUT / "correlation_heatmap.png", dpi=160)
    plt.close()

    # Non-parametric group comparison: ratings across product categories
    groups = [g["product_rating"].dropna().values
              for _, g in df.groupby("product_category") if g["product_rating"].notna().sum() > 1]
    if len(groups) >= 2:
        h, p = stats.kruskal(*groups)
        report.append(f"\\nKruskal-Wallis rating comparison across categories: H={h:.3f}, p={p:.4f}.")
        report.append("Interpret p-values with effect size, sample size, and business context; this is exploratory.")
    (OUT / "eda_summary.txt").write_text("\\n".join(report), encoding="utf-8")
    return report

def engineer_and_export(df):
    engineered = create_features(df)
    engineered.to_csv(OUT / "beauty_wellness_engineered.csv", index=False)

    numeric_features = [
        "age", "average_order_value", "product_rating", "purchase_count",
        "days_since_last_purchase", "discount_percent", "review_count",
        "estimated_total_spend", "purchase_frequency_proxy",
        "discount_spend_interaction", "rating_review_interaction"
    ]
    categorical_features = [
        "skin_type", "product_category", "loyalty_tier",
        "age_group", "recency_segment", "rating_band"
    ]
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore"))
    ])
    prep = ColumnTransformer([
        ("numeric", numeric_pipe, numeric_features),
        ("categorical", categorical_pipe, categorical_features)
    ])
    transformed = prep.fit_transform(engineered)
    feature_names = prep.get_feature_names_out()
    dense = transformed.toarray() if hasattr(transformed, "toarray") else transformed
    processed = pd.DataFrame(dense, columns=feature_names)
    processed.to_csv(OUT / "model_ready_features.csv", index=False)
    return engineered, processed

def main():
    df = load_data()
    print("Loaded data:", df.shape)
    print("This dataset is synthetic; results are for workflow demonstration only.")
    run_eda(df)
    engineered, processed = engineer_and_export(df)
    print("Created outputs in:", OUT)
    print("Engineered dataset shape:", engineered.shape)
    print("Model-ready feature matrix shape:", processed.shape)
    print("Review outputs/eda_summary.txt and PNG charts before interpreting results.")

if __name__ == "__main__":
    main()
