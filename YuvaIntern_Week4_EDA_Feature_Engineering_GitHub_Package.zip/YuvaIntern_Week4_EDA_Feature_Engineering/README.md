# YuvaIntern Data Science — Week 4
## Exploratory Data Analysis and Feature Engineering
**Project theme:** Beauty & Wellness AI Personalization and Retention System

### Contents
- `data/beauty_wellness_customers.csv` — synthetic example data for a reproducible demo.
- `src/eda_feature_engineering.py` — EDA, visualizations, statistical comparison, feature engineering and preprocessing pipeline.
- `outputs/` — generated charts, summary and transformed features after running the script.
- `Week4_EDA_Feature_Engineering_Report.docx` — detailed report.
- `Week4_EDA_Feature_Engineering_Presentation.pptx` — summary slides.

### Run locally
1. Install Python 3.10 or newer.
2. In a terminal, run `pip install -r requirements.txt`.
3. Run `python src/eda_feature_engineering.py`.
4. Review generated files in `outputs/`.

### Important data note
The included data is **synthetic demonstration data**, not real customer data and not a claim of actual market findings. To analyze real data, replace the CSV with the approved, preprocessed dataset and preserve the expected column names. Do not upload customer personal information or confidential business data to a public repository.

### Workflow
1. Validate columns, data types, missingness and duplicates.
2. Review descriptive statistics and distributions.
3. Plot missingness, order value by category and numeric correlations.
4. Use Kruskal–Wallis as an exploratory non-parametric comparison of ratings across product categories.
5. Create recency segments, age groups, purchase-frequency proxy, interaction features and customer value flag.
6. Impute missing values, standardize numeric features and one-hot encode categorical features.
7. Inspect the charts and summary before using features in a downstream model.

### Interpretation and leakage precautions
`churn_risk_label` is a simulated label for future workflow extension. The script deliberately does not include it among model-ready input features. For real predictive modeling, define the prediction date, calculate features using only information available at that date, split data appropriately, and evaluate on a held-out set.
